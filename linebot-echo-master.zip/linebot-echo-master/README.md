# linebot-echo
Basic Line Bot that can echo your text msg.

fork from [SDK of the LINE Messaging API for Python](https://github.com/line/line-bot-sdk-python)
